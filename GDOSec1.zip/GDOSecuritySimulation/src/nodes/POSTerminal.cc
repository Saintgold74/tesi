#include <omnetpp.h>

using namespace omnetpp;

class POSTerminal : public cSimpleModule
{
protected:
    virtual void initialize() override {
        EV << "POS Terminal " << getIndex() << " initialized\n";
    }

    virtual void handleMessage(cMessage *msg) override {
        delete msg;
    }
};

Define_Module(POSTerminal);
